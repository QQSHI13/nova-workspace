package com.qq.skylight.mixin;

import com.qq.skylight.camera.FreeCamera;
import com.qq.skylight.state.SkylightState;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Mixin to handle free camera rendering.
 * Overrides camera position and rotation when freecam is active.
 */
@Mixin(class_757.class)
public class GameRendererMixin {

    /**
     * Updates the camera for freecam mode.
     */
    @Inject(method = "renderWorld", at = @At("HEAD"))
    private void onRenderWorld(class_9779 tickCounter, CallbackInfo ci) {
        // Free camera position is handled in CameraMixin
    }
}