package com.qq.skylight.mixin;

import com.qq.skylight.config.SkylightConfig;
import net.minecraft.class_1267;
import net.minecraft.class_2535;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.class_8792;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin that handles player join events to automatically set Peaceful difficulty.
 */
@Mixin(class_3324.class)
public class PlayerJoinMixin {

    /**
     * Injects into the player connect method to set difficulty to Peaceful.
     * Note: 1.21.1+ requires ConnectedClientData as the third parameter.
     */
    @Inject(method = "onPlayerConnect", at = @At("TAIL"))
    private void skylight$onPlayerConnect(class_2535 connection, class_3222 player, class_8792 clientData, CallbackInfo ci) {
        if (SkylightConfig.getConfig().autoPeacefulEnabled && player.method_5682() != null) {
            player.method_5682().method_3776(class_1267.field_5801, true);
        }
    }
}
