package com.qq.skylight.mixin;

import com.qq.skylight.config.SkylightConfig;
import net.minecraft.class_2678;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin that handles client join events to automatically enable auto-jump.
 */
@Mixin(class_634.class)
public class ClientJoinMixin {

    /**
     * Injects into the game join handler to enable auto-jump.
     */
    @Inject(method = "onGameJoin", at = @At("TAIL"))
    private void skylight$onGameJoin(class_2678 packet, CallbackInfo ci) {
        if (SkylightConfig.getConfig().autoJumpEnabled) {
            class_310.method_1551().field_1690.method_42423().method_41748(true);
        }
    }
}
