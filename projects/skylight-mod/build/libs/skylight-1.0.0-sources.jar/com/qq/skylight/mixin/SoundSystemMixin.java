package com.qq.skylight.mixin;

import com.qq.skylight.config.SkylightConfig;
import com.qq.skylight.state.SkylightState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_2960;

/**
 * Mixin to cancel hostile mob sounds when skylight mode is active.
 */
@Mixin(class_1140.class)
public class SoundSystemMixin {

    private static final Set<String> HOSTILE_MOB_PREFIXES = Set.of(
            "entity.zombie",
            "entity.skeleton",
            "entity.creeper",
            "entity.spider",
            "entity.enderman",
            "entity.witch",
            "entity.slime",
            "entity.phantom",
            "entity.drowned",
            "entity.husk",
            "entity.stray",
            "entity.cave_spider",
            "entity.silverfish",
            "entity.endermite",
            "entity.ravager",
            "entity.vindicator",
            "entity.evoker",
            "entity.vex",
            "entity.pillager",
            "entity.illusioner",
            "entity.guardian",
            "entity.elder_guardian",
            "entity.warden",
            "entity.blaze",
            "entity.ghast",
            "entity.hoglin",
            "entity.piglin",
            "entity.piglin_brute",
            "entity.zoglin",
            "entity.zombified_piglin",
            "entity.magma_cube",
            "entity.shulker",
            "entity.wither",
            "entity.wither_skeleton"
    );

    @Inject(method = "play(Lnet/minecraft/client/sound/SoundInstance;)V", at = @At("HEAD"), cancellable = true)
    private void onPlay(class_1113 sound, CallbackInfo ci) {
        SkylightConfig config = SkylightConfig.getConfig();
        if (!config.enableSoundMute || !SkylightState.isSkylightModeActive()) {
            return;
        }

        // Check if this is a hostile mob sound
        class_2960 id = sound.method_4775();
        String path = id.method_12832();

        for (String prefix : HOSTILE_MOB_PREFIXES) {
            if (path.startsWith(prefix)) {
                ci.cancel();
                return;
            }
        }
    }
}
