package com.qq.skylight;

import com.qq.skylight.config.SkylightConfig;
import com.qq.skylight.screenshot.ScreenshotHandler;
import com.qq.skylight.state.SkylightState;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1267;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/**
 * Handles keybinding registration and input processing for Skylight mod.
 */
public class SkylightKeybinds {

    private static class_304 skylightModeKey;
    private static class_304 screenshotKey;

    /**
     * Registers all keybindings for the mod.
     */
    public static void register() {
        SkylightConfig config = SkylightConfig.getConfig();

        // Main skylight mode toggle (K key)
        skylightModeKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.skylight.mode",
                class_3675.class_307.field_1668,
                config.skylightModeKey.keyCode,
                "category.skylight.general"
        ));

        // Screenshot key (C key)
        screenshotKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.skylight.screenshot",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_C,
                "category.skylight.general"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (skylightModeKey.method_1436()) {
                toggleSkylightMode(client);
            }
            if (screenshotKey.method_1436()) {
                takeScreenshot(client);
            }
        });
    }

    /**
     * Toggles skylight mode on/off.
     * In normal games: toggles peaceful + HUD + sound mute
     * In locked games (hardcore/locked difficulty): only toggles HUD + sound mute
     */
    private static void toggleSkylightMode(class_310 client) {
        SkylightConfig config = SkylightConfig.getConfig();
        boolean nowActive = SkylightState.toggle();

        if (client.field_1724 == null) return;

        if (nowActive) {
            // Activating skylight mode
            boolean difficultyChanged = false;

            // Only change difficulty if enabled in config AND difficulty can be changed
            if (config.enablePeacefulOnToggle && canChangeDifficulty(client)) {
                if (client.method_1576() != null) {
                    client.method_1576().method_3776(class_1267.field_5801, false);
                    SkylightState.setOriginalDifficulty(client.field_1687.method_8407());
                    difficultyChanged = true;
                }
            }

            // Show appropriate message
            if (difficultyChanged) {
                client.field_1724.method_7353(class_2561.method_43471("message.skylight.mode.enabled"), true);
            } else {
                client.field_1724.method_7353(class_2561.method_43471("message.skylight.mode.enabled_no_difficulty"), true);
            }
        } else {
            // Deactivating skylight mode
            // Restore original difficulty if we changed it
            if (SkylightState.getOriginalDifficulty() != null && canChangeDifficulty(client)) {
                if (client.method_1576() != null) {
                    client.method_1576().method_3776(SkylightState.getOriginalDifficulty(), false);
                }
            }

            client.field_1724.method_7353(class_2561.method_43471("message.skylight.mode.disabled"), true);
        }

        SkylightMod.LOGGER.info("Skylight mode {} by player {}",
                nowActive ? "enabled" : "disabled",
                client.field_1724.method_5477().getString());
    }

    /**
     * Takes a screenshot using Skylight's enhanced screenshot handler.
     */
    private static void takeScreenshot(class_310 client) {
        if (!SkylightConfig.getConfig().photography.enableScreenshot) {
            if (client.field_1724 != null) {
                client.field_1724.method_7353(class_2561.method_43471("message.skylight.screenshot.disabled_config"), true);
            }
            return;
        }
        ScreenshotHandler.takeScreenshot(client);
    }

    /**
     * Checks if the current world allows difficulty changes.
     * Returns false for hardcore worlds or locked difficulty.
     */
    private static boolean canChangeDifficulty(class_310 client) {
        if (client.field_1687 == null) return false;

        // Check if hardcore (difficulty locked)
        if (client.field_1687.method_28104().method_152()) {
            return false;
        }

        // Check if difficulty is explicitly locked
        if (client.field_1687.method_28104().method_197()) {
            return false;
        }

        return true;
    }
}