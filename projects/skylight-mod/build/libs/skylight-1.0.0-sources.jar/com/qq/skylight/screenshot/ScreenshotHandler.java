package com.qq.skylight.screenshot;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import net.minecraft.class_1011;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_318;

/**
 * Handles enhanced screenshot functionality.
 * Saves screenshots to a custom Skylight gallery folder with timestamps.
 */
public class ScreenshotHandler {
    
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
    private static final String SCREENSHOTS_FOLDER = "skylight-gallery";
    
    /**
     * Takes a screenshot and saves it to the Skylight gallery folder.
     */
    public static void takeScreenshot(class_310 client) {
        if (client.field_1724 == null) return;
        
        // Get screenshot directory
        Path screenshotDir = Paths.get(client.field_1697.getAbsolutePath(), SCREENSHOTS_FOLDER);
        
        try {
            // Create directory if it doesn't exist
            if (!Files.exists(screenshotDir)) {
                Files.createDirectories(screenshotDir);
            }
            
            // Generate filename with timestamp
            String timestamp = LocalDateTime.now().format(DATE_FORMATTER);
            String filename = "skylight_" + timestamp + ".png";
            
            // Take screenshot using Minecraft's built-in method
            class_1011 screenshot = class_318.method_1663(client.method_1522());
            File screenshotFile = new File(screenshotDir.toFile(), filename);
            
            screenshot.method_4325(screenshotFile);
            screenshot.close();
            
            // Notify player
            client.field_1724.method_7353(
                class_2561.method_43469("message.skylight.screenshot.saved", filename),
                true
            );
            
        } catch (IOException e) {
            client.field_1724.method_7353(
                class_2561.method_43469("message.skylight.screenshot.failed", e.getMessage()),
                true
            );
        }
    }
    
    /**
     * Opens the Skylight gallery folder in the system file explorer.
     */
    public static void openGalleryFolder(class_310 client) {
        Path screenshotDir = Paths.get(client.field_1697.getAbsolutePath(), SCREENSHOTS_FOLDER);
        
        try {
            if (!Files.exists(screenshotDir)) {
                Files.createDirectories(screenshotDir);
            }
            
            // Open folder using system default
            class_156.method_668().method_672(screenshotDir.toFile());
            
        } catch (IOException e) {
            if (client.field_1724 != null) {
                client.field_1724.method_7353(
                    class_2561.method_43469("message.skylight.gallery.open.failed", e.getMessage()),
                    true
                );
            }
        }
    }
}