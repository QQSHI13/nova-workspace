package com.qq.skylight.mixin;

import com.qq.skylight.config.SkylightConfig;
import net.minecraft.class_1267;
import net.minecraft.class_1304;
import net.minecraft.class_1690;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1893;
import net.minecraft.class_1928;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7924;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin to handle player spawning with Skylight World settings.
 * Gives the player elytra, firework rockets, and spawns a boat nearby.
 */
@Mixin(class_3222.class)
public class ServerPlayerEntityMixin {

    @Inject(method = "onSpawn", at = @At("TAIL"))
    private void skylight$onPlayerSpawn(CallbackInfo ci) {
        if (!SkylightConfig.getConfig().createSkylightWorld) {
            return;
        }

        class_3222 player = (class_3222) (Object) this;
        class_3218 world = player.method_51469();

        // Set world to peaceful
        if (world.method_8503() != null) {
            world.method_8503().method_3776(class_1267.field_5801, true);
        }

        // Enable natural regeneration (no hunger)
        world.method_8450().method_20746(class_1928.field_19395).method_20758(true, world.method_8503());

        // Give unbreaking elytra
        class_1799 elytra = new class_1799(class_1802.field_8833);

        // Get enchantments from registry
        var enchantmentRegistry = world.method_30349().method_30530(class_7924.field_41265);

        enchantmentRegistry.method_40264(class_1893.field_9119).ifPresent(entry -> {
            elytra.method_7978(entry, 3);
        });

        enchantmentRegistry.method_40264(class_1893.field_9101).ifPresent(entry -> {
            elytra.method_7978(entry, 1);
        });

        player.method_5673(class_1304.field_6174, elytra);

        // Give stack of firework rockets
        class_1799 fireworks = new class_1799(class_1802.field_8639, 64);
        player.method_31548().method_7394(fireworks);

        // Spawn a boat near the player
        class_2338 playerPos = player.method_24515();
        class_243 boatPos = new class_243(playerPos.method_10263() + 2, playerPos.method_10264(), playerPos.method_10260());

        class_1690 boat = new class_1690(world, boatPos.field_1352, boatPos.field_1351, boatPos.field_1350);
        // Default boat type is oak
        world.method_8649(boat);
    }
}