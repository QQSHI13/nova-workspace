package com.qq.skylight.camera;

import com.qq.skylight.state.SkylightState;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_5498;

/**
 * Handles free camera mode for cinematic shots.
 * Allows the camera to detach from the player and fly freely.
 */
public class FreeCamera {
    
    private static final FreeCamera INSTANCE = new FreeCamera();
    
    private boolean active = false;
    private class_243 cameraPos = class_243.field_1353;
    private float yaw = 0;
    private float pitch = 0;
    private class_5498 originalPerspective;
    
    private FreeCamera() {}
    
    public static FreeCamera getInstance() {
        return INSTANCE;
    }
    
    /**
     * Toggles free camera mode on/off.
     */
    public void toggle(class_310 client) {
        if (active) {
            disable(client);
        } else {
            enable(client);
        }
    }
    
    /**
     * Enables free camera mode.
     */
    public void enable(class_310 client) {
        if (client.field_1724 == null) return;
        
        active = true;
        SkylightState.setFreeCamActive(true);
        
        // Store current camera position and rotation
        class_4184 camera = client.field_1773.method_19418();
        cameraPos = camera.method_19326();
        yaw = camera.method_19330();
        pitch = camera.method_19329();
        
        // Store original perspective and switch to first person
        originalPerspective = client.field_1690.method_31044();
        client.field_1690.method_31043(class_5498.field_26664);
        
        // Hide player model in freecam
        client.field_1724.method_5648(true);
        
        if (client.field_1724 != null) {
            client.field_1724.method_7353(net.minecraft.class_2561.method_43471("message.skylight.freecam.enabled"), true);
        }
    }
    
    /**
     * Disables free camera mode.
     */
    public void disable(class_310 client) {
        if (!active) return;
        
        active = false;
        SkylightState.setFreeCamActive(false);
        
        // Restore original perspective
        if (originalPerspective != null) {
            client.field_1690.method_31043(originalPerspective);
        }
        
        // Show player model again
        if (client.field_1724 != null) {
            client.field_1724.method_5648(false);
            client.field_1724.method_7353(net.minecraft.class_2561.method_43471("message.skylight.freecam.disabled"), true);
        }
    }
    
    /**
     * Updates the free camera position based on player input.
     * Called every tick while freecam is active.
     */
    public void update(class_310 client) {
        if (!active || client.field_1724 == null) return;
        
        // Handle movement input
        float forward = 0;
        float sideways = 0;
        float vertical = 0;
        
        if (client.field_1690.field_1894.method_1434()) forward += 1;
        if (client.field_1690.field_1881.method_1434()) forward -= 1;
        if (client.field_1690.field_1913.method_1434()) sideways += 1;
        if (client.field_1690.field_1849.method_1434()) sideways -= 1;
        if (client.field_1690.field_1903.method_1434()) vertical += 1;
        if (client.field_1690.field_1832.method_1434()) vertical -= 1;
        
        // Calculate movement speed (sprint = faster)
        float speed = client.field_1690.field_1867.method_1434() ? 2.0f : 0.5f;
        
        // Convert yaw to radians
        float yawRad = (float) Math.toRadians(yaw);
        float cosYaw = (float) Math.cos(yawRad);
        float sinYaw = (float) Math.sin(yawRad);
        
        // Calculate movement vector
        double dx = (sideways * cosYaw - forward * sinYaw) * speed;
        double dz = (forward * cosYaw + sideways * sinYaw) * speed;
        double dy = vertical * speed;
        
        // Update camera position
        cameraPos = cameraPos.method_1031(dx, dy, dz);
    }
    
    /**
     * Updates camera rotation from mouse input.
     */
    public void updateRotation(double deltaX, double deltaY) {
        if (!active) return;
        
        float sensitivity = 0.15f;
        yaw += deltaX * sensitivity;
        pitch = Math.max(-90, Math.min(90, pitch - (float)(deltaY * sensitivity)));
    }
    
    public boolean isActive() {
        return active;
    }
    
    public class_243 getCameraPos() {
        return cameraPos;
    }
    
    public float getYaw() {
        return yaw;
    }
    
    public float getPitch() {
        return pitch;
    }
}